#include <stdio.h>
#define line "\t-------------------------------------------------\n"

main()
{
   int i = 0;
   char c = 'a';
   short s = 1;
   long l = 2;
   float f = 3.0;
   double d = 4.0;

   printf("Variable Table\n");
   printf(line);
        printf("\tVar\t\tAddress\t\tValue\n");
   printf(line);
   printf("\t%s\t\t%p\t%d\n","i", &i, i);
   printf("\t%s\t\t%p\t%c\n","c", &c, c);
   printf("\t%s\t\t%p\t%d\n","s", &s, s);
   printf("\t%s\t\t%p\t%d\n","l", &l, l);
   printf("\t%s\t\t%p\t%f\n","f", &f, f);
   printf("\t%s\t\t%p\t%f\n","d", &d, d);
   printf(line);
}
