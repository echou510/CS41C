#include <stdio.h> 
#include <stdlib.h>
int a=3; int b=5; 
static int c[2] = {1, 2};
static int d[3];   // The keyword static is redundent in this case
int *f; 

int main(void){
     int i=0; 
	 int e[2] = {9, 8}; 
	 int *g; 
	 printf("Global Int: \n"); 
     printf("%-0x = %d\n", &a, a); 	     printf("%-0x = %d\n", &b, b); 	  
	 printf("Global Initialized Array\n"); 
	 printf("%-0x = %d\n", &c[0], c[0]); 	  printf("%-0x = %d\n", &c[1], c[1]); 	
	 printf("Global Uninitialized:\n"); 
	 for (i=0; i<3; i++){
	      d[i] = i;   // allocated at this time
		  printf("%-0x = %d\n", &d[i], d[i]); 
	 }
	 printf("Local Initialized Array\n"); 
	 printf("%-0x = %d\n", &e[0], e[0]); 	  printf("%-0x = %d\n", &e[1], e[1]); 	
	 printf("Global Dynamic Array:\n"); 
	 f = calloc(3, sizeof(int));     
	 for (i=0; i<3; i++){
	      f[i] = i*2;   // allocated at this time
		  printf("%-0x = %d\n", &f[i], f[i]); 
	 }
	 printf("Local Dynamic Array:\n"); 
	 g = calloc(3, sizeof(int));     
	 for (i=0; i<3; i++){
	      g[i] = i*2;   // allocated at this time
		  printf("%-0x = %d\n", &g[i], g[i]); 
	 }
	 return 0; 
}