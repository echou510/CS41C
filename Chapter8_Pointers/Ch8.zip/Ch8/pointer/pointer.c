#include <stdio.h>
#define line "\t--------------------------------------\n"

main()
{
  int i = 0;
  int j = 1;
  int k = 2;
  float f = 3.0;
  int *p = 0;

  p = &k;
  printf("p = %p\t\t*p = %d\n", p, *p);

  j = *p + 5;
  printf("j = %d\t\t*p = %d\n", j, *p);

  *p = *p + i;
  printf("p = %p\t\t*p = %d\n", p, *p);

  p = (void *) &f;
  printf("p = %p\t\t*p = %d\n", p, *p);
}
