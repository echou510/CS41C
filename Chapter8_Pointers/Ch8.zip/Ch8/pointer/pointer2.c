#include <stdio.h>
main(){
    int a, *pa, **ppa; 
	int b=10; 
	int *pb;
    pa = &a; 
    ppa = &pa; 
    a = 3; 
	
	pb=&b;

   if (*pa == 3) printf("*pa==%d (a) Checked\n", a);
   if (**ppa ==3) printf("**ppa==%d (a) Checked\n", a);
   
   *ppa = &b;   // *ppa means pa
   printf("When *ppa updated, See how pa got updated. *pa=%d and b=%d\n", *pa, b); 
   *pa = 6;        // At this moment, pa is pointint to b
    printf("When *pa (to b) updated, See how b got updated. *pa=%d and b=%d\n", *pa, b); 
	*ppa = &a;   // ppa's body (pa) is updated to a
    **ppa = 7; 	// **ppa, *pa, a got updated. 
	printf("After **ppa=7 => **ppa=%d, *pa=%d, a=%d\n", **ppa, *pa, a); 
}  


