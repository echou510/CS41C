#include <stdio.h>

void swap1(int a, int b) {
  int temp = a;
  a = b;
  b = temp; 
}

void swap2(int *pa, int *pb) {
  int temp = *pa;
  *pa = *pb;
  *pb = temp;
}

main() {
  int a = 3, b = 5;

  swap1(a, b);
  printf("Pass by value     = %d  %d\n", a, b);
  swap2(&a, &b);
  printf("Pass by Reference = %d  %d\n", a, b);
}
