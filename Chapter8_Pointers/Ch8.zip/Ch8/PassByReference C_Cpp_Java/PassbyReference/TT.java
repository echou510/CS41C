
/**
 * Write a description of class TT here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TT
{
   public static int jf(Integer ia, int x){
       ia = x; 
       return ia.intValue(); 
    }
   public static void main(String[] args){
      Integer a = new Integer(3); 
      System.out.printf("a before call = %d\n", a); 
      a = jf(a, 4); 
      System.out.printf("a after call = %d\n", a.intValue()); 
      
    }
}
