
/**
 * Write a description of class RR here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RR
{
    public static int[] jf(int[] ia, int[] x){
        ia[0] = x[0]; 
        ia[1] = x[1]; 
        return ia; 
    }
    
    public static void main(String[] args){
       int[] a = {1, 2}; 
       int[] b = {3, 4}; 
       System.out.printf("a[] before call = %d %d\n", a[0], a[1] ); 
       jf(a, b); 
       System.out.printf("a[] after call = %d %d\n", a[0], a[1] ); 
       jf(a, b); 
    }
}
