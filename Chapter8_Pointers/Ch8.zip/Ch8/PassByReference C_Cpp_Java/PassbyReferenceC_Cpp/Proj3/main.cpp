#include <iostream>

using namespace std; 

int f(int &ia, int x){
	ia =x; 
	return ia; 
}
int main(int argc, char** argv) {
	int a = 3; 
	printf("a before call = %d\n", a);
	f(a, 4); 
	printf("a after call = %d\n", a);  
	return 0;
}


