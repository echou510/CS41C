#include <iostream>
#include <cstdlib>   // C language stdlib.h file 
#include "aa.h"

using namespace std; 

namespace a{
  int i=1; 
  int j=2; 
}

namespace b{
 int i=3;
 int j=4;  
}


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
    using namespace b; 
    i++; 
    cout << "a" << "b" << "c" << "d" << "e" << "\n"; 
	cout << i << endl; 	
	int &ai = i; 
	ai++; 
	cout << "Alias =" << float(i+0.1) << "  " << ai << endl; 		
	cout << a::i << endl; 
	cout << "Hello World!!!" << endl; 
	printf("%d %d\n", ai, i); 
	return EXIT_SUCCESS;  // 0 for EXIT_SUCCESS  1 for EXIT_FAILURE
}
