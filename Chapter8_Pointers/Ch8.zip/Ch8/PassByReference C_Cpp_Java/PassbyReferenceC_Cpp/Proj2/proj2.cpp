#include <iostream>
#include <cstdlib>

using namespace std; 

namespace a{
   int i= 0; 
   int j= 1; 
   char a = 'A'; 
}

namespace b{
  int i=5; 
  int j=10; 
  char a = 'a'; 
}

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	cout << "Welcome to C++ Programming: " << endl; 
	cout << "a::i=" << a::i << endl; 
	cout << "b::i=" << b::i << endl;   
	using namespace a; 
    cout << "i in a opened =" << i << endl; 
    cout << float(++i + 0.5) << endl; 
    
    
    int a=3; 
    int &b = a; 
    b++; 
    printf("b=%d a=%d\n", b, a); 
    
    cout << "a" << "b" << "c" << "d" << "e" << endl; 
	return EXIT_SUCCESS;  // EXIT_SUCCESS is 0, EXIT_FAILURE is 1 
}
