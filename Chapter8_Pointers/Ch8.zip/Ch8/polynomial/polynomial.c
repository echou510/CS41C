#include <stdio.h>
#include <math.h>

main() {
  int i, order;
  float coef[10], x, val;
  
  printf( "Enter the order -> " );
  scanf("%d" , &order);
  for ( i = 0; i <= order; i++ ){
    printf("a[%d] = ", i);
    scanf("%f", &(coef[i]) );
  }

  for ( x = 0; x <= 1; x += 0.1 ){
    val = coef[0];
    for ( i = 1; i <= order; i++ )
    	val += coef[i] * pow(x,i);
    
    printf("%f\t%f",x,val);
  }
}
  
