#include <stdio.h> 
#include <stdlib.h>

int main(int argc, char *argv[]){
 int i; 
 for (i = 1; i < argc; i++)
      printf("%s ", argv[i]);
  printf("\n");
  if (argc >= 3){
   printf("First Argument = %d\n", atoi(argv[1]));
   printf("Second Argument = %8.4f\n", atof(argv[2])); 
  }   
 return 0;
}

