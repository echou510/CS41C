#include <stdio.h>

void main(void){
  int i = 0;
  int j = 1;
  int k = 2;
  int *p = 0;
  int **f; 
  p = &i;
  printf("p = %p\t\t*p = %d\n", p, *p);
  p = p + 1;
  printf("p = %p\t\t*p = %d\n", p, *p);
  p++ ;
  printf("p = %p\t\t*p = %d\n", p, *p);
  f = &p;
  printf("p = %p\t\t*p = %d\n", *f, **f);  // p's location and its value
}


