#include <stdio.h>
#include <stdlib.h>
#define SIZE 3

int cube[SIZE][SIZE][SIZE]= {
  {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}}, 
  {{10, 11, 12}, {13, 14, 15}, {16, 17, 18}}, 
  {{19, 20, 21}, {22, 23, 24}, {25, 26, 27}}
 }; 

int main(int argc, char *argv[]) {
	int i=0; 
	int j=0; 
	int k=0; 
	for (i=0; i<SIZE; i++) {
	  for (j=0; j<SIZE; j++) {
	  for (k=0; k<SIZE; k++){
	   printf("%2d ", cube[i][j][k]); 
      }
      printf("\n"); 
	 }
    }
	
	return 0;
}


