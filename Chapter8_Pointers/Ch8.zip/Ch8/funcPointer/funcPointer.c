#include <stdio.h>
int square(int x){
    return x * x; 
}

int doubled(int x ){
    return 2 * x; 
}

int run(int (*f)(int), int x){
      return f(x); 
} 

int main(int argc, char** argv) {
	printf("square(3)=%d\n", run(&square, 3)); 
	printf("double(3)=%d\n", run(&doubled, 3)); 
	return 0;
}


