#include <stdio.h>
#include <stdlib.h>

int (*function[3])(int);  // 3 element array of function  pointers

int f1(int x){
	return x; 
} 
int f2(int y){
    return y; 
} 
int f3(int z){
	return z;
} 


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	function[0]=&f1; 
	function[1]=&f2; 	
	function[2]=&f3; 
	int i=0; 
	for (i=0; i<3; i++){
		printf("function[%d](%d)=%d\n", i, i*2, function[i](i*2)); 
	}
	 
	return 0;
}


