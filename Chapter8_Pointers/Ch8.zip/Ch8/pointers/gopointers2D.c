gcc pointers2D.c -o pointers2D
pointers2D