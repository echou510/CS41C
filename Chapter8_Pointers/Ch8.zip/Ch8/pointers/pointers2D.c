#include <stdio.h> 
#include <stdlib.h> 
int c[][2] = {1, 2, 3, 4};   // row-major 2D array 
int **a;                                // pointer of pointers
int *b[2] ;                            // array of pointers (2 row pointers)
int main(void){
   int i, j;
   a = (int **) calloc(2, sizeof(int *)); 
   a[0] = c[0];  a[1] = c[1]; 
   b[0] = c[0];  b[1]  =c[1];   
   printf("Using a pointer to pointers\n"); 
   for (i=0; i<2; i++) { 
               for (j=0; j<2; j++) printf("%d ", a[i][j]); 
			   printf("\n"); 
	}
	printf("Using b 1D array of pointers\n"); 
	for (i=0; i<2; i++) { 
               for (j=0; j<2; j++) printf("%d ", b[i][j]); 
			   printf("\n"); 
	}
	printf("Using c 2D - array\n"); 
	for (i=0; i<2; i++) { 
               for (j=0; j<2; j++) printf("%d ", c[i][j]); 
			   printf("\n"); 
	}
	return 0; 
} 



