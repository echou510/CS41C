#include<stdio.h>
void main() { 
    char sp[20]; 
    printf("Enter a string: "); 
    gets(sp); // input.nextLine()
    puts(sp); // System.out.println(sp); 
    getch(); 
}