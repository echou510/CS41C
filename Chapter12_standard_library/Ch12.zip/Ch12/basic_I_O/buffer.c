#include <stdio.h>
#include <conio.h>
int main(){
   int i ,j;
   char name[ 10 ] ;
   char o_name[10];
   printf(" Enter name \n ") ;
   for( i=0 ; i <= 10 ; i++ ){
    name[i] = getch();
    putch(i);
   }
   printf(" Enter other name \n ") ;
   for( j=0 ; j <= 10 ; j++ ){
    name[j] = getche();
    putch(j);
   }
}