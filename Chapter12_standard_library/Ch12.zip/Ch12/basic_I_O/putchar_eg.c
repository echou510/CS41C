#include <stdio.h>
#include <conio.h>
void main( ){
    int a;
    printf("Enter a character: ");
    a=getchar();
    putchar(a);
    getch(); // wait for one keyboard stroke
}