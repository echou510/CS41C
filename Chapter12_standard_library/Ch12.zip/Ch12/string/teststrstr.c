#include <stdio.h>
#include <string.h>
int main()
{
     char inputstr[70] = "String Function in C at BeginnersBook.COM";
     printf ("Output string is: %s", strstr(inputstr, 'Begi'));
     return 0;
}