#include <stdio.h>
#include <string.h>
int main()
{
     char str1[20] = "eC Academy";
     printf("Length of string str1 when maxlen is 30: %d", strnlen(str1, 30));
     printf("Length of string str1 when maxlen is 10: %d", strnlen(str1, 10));
     return 0;
}