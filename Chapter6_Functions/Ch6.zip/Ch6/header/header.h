//Avoidance of re-declaration
#ifndef _HUFFMAN_H
#define _HUFFMAN_H
// Inclusion of other .h files (from public library or user defined files)
#include <stdint.h>
#include <stdbool.h>
#include "code.h"
// definition of constants
#ifndef NIL
#define NIL (void *) 0
#endif
// definition of macros
#define DEBUG 1
// type declarations
typedef struct DAH{
  uint8_t symbol ;  
  bool leaf ;
  uint64_t count ;
  treeNode *left , *right ;
};
// inline functions
static inline void delNode(treeNode *h) { free (h); return ; }
static inline int8_t compare(treeNode *l, treeNode *r){
   return l-> count - r-> count ; // l < r if negative , l = r if 0, ...
}
// functional prototypes (functional declarations)
treeNode *newNode (uint8_t s, bool l, uint64_t c);
treeNode *delTree(treeNode *t);
void dumpTree(treeNode *t, FILE *fp); 
void loadHuffmanBuffer(FILE *, uint64_t); 
treeNode *loadTree (uint8_t *savedTree, uint64_t c);
void buildCode(treeNode *t, code *s, code table[256]) ;
#endif

