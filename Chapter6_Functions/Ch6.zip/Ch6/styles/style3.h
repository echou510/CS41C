void add_print(int, int);

