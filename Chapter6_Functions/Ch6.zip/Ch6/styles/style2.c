#include <stdio.h>
//function definition
void add_print(int val1,int val2){
	int c;
	printf("The two values entered are:%d,%d \n",val1,val2);
	c=val1+val2;
	printf("Sum of numbers entered is:%d \n",c);
}
int main(){
	int a=4;
	int b=5;
	printf("Entering �add_print� function\n");
	add_print(a,b);
	printf("Just came from �add_print� function\n");
    return 0;
}




