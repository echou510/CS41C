#include <stdio.h> 
int sumt(int n, int s){
  if (n==1) return s+1; 
  int ss = s +n; 
  return sumt(n-1, ss); 
}
int sum(int n){
	return sumt(n, 0); 
}
int main(void){
  printf("Sum from 1 to %d is %d\n", 10, sum(10)); 
  return 0; 
}

