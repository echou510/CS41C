#include "a.h"
int i = 2;

int f() { 
  i++; 
  return i;
 }
 
 