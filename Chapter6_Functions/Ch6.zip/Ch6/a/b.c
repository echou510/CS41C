#include <stdio.h>
#include "a.h"

int main(void){
    printf("%d\n", f());
    return 0;
}

