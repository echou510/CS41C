extern int i;
int f(void);

