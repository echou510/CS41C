#include <stdio.h> 
int fibt(int n, int s1, int s2){
  if (n==0 || n==1) return 1; 
  int sum=s1+s2; 
  return sum; 
}

int fib(int n){
	if (n==0 || n==1) return 1; 
	return fibt(n, fib(n-1), fib(n-2)); 
}
int main(void){
  int i; 
  printf("Enter an integer: "); 
  scanf("%d", &i); 
  printf("Fibonacii(%d)=%d\n", i, fib(i)); 
  return 0; 
}

