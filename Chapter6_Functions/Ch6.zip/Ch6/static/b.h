#ifndef _B_
#define _B_
#endif