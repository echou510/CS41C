#include <stdio.h>
#include "a.h"

static int x = 3; 
int z = 5; 
static void f(){
	printf("Main's static f() \n"); 
}

int main(){
	printf("Main()================\n"); 
	printf("main's x=%d\n", x);
    y++; 	
	printf("main's y=%d\n", y); 
	printf("main's z=%d\n", z);
	other(); 
	return 0; 
}