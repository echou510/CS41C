#include <stdio.h>
#include "b.h"
#include "a.h"
int x = 15; 
//int z=100; 
extern int z; 
void g(){
	printf("B's g()\n"); 
}

void stranger(){
	printf("Stranger() =================\n"); 
	printf("Stranger's x=%d\n", x); 
	y++; 
	printf("Stranger's y=%d\n", y); 
	z++; 
	printf("Stranger's z=%d\n", z); 
	g(); 
}