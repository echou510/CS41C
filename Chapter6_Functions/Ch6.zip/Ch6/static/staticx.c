#include<stdio.h>
static x=3; 

void func(){
    printf("f=%d\n", x); 
}
int main(void){
	func(); 
    printf("Main=%d\n", x); 
	x=4;
	func(); 
    return 0;
}


