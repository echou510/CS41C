#ifndef _A_
#define _A_
extern int y; 
extern void other(void);    // shared function other(void) 
#endif