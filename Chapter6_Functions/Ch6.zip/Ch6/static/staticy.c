#include<stdio.h>
static x=3; 
int y=3; 
void func(){
	int y=10; 
    printf("f(x)=%d\n", x);     
	printf("f(y)=%d\n", y); 
}
int main(void){
	func(); 
    printf("Main(x)=%d\n", x); 
	printf("Main(y)=%d\n", y); 
	x=4; y=4; 
	func(); 
    return 0;
}


