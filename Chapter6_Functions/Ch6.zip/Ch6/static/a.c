#include <stdio.h>
#include "a.h"
static x = 4; 
int y=6; 
extern int z; 
static f(){
	printf("A's f() \n");
}

void other(){	 
    printf("A's other() =========== \n");
	printf("other's static x=%d\n", x); 
	printf("other's           y=%d\n", y); 
	z++; 
	printf("other's           z=%d\n", z); 
     f(); 	 
	 stranger(); 
	 printf("other calling\n");
     g(); 	 
}