#include <stdio.h>
static int callNo =0; 
void f(){
    static x=0; 
	callNo++; 
	x++; 
	printf("x=%d\n", x); 
}
void g(){
    static y=0; 
	callNo++; 
	y++; 
	printf("y=%d\n", y); 
}

int main(void){
  f(); g(); f(); g(); f(); g(); printf("Total Function Calls=%d\n", callNo); 
  return 0; 
}

