#include <stdio.h>

void welcome(){
  printf("welcome. \n"); 
}

int main(void){
   welcome(); welcome(); welcome();  
}
