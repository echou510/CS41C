#include <stdio.h>
#define max(a, b)                        \
              (                                       \
			       { typeof(a) _a = (a); \
				      typeof(b) _b = (b); \
					  _a > _b ? _a: _b;} \
			   )
			   	   
int main(void){
    int x = 1; 
	int y = 2; 
	
	int c = max(x, y); 
	
    printf("%d %d %d\n", x, y, c); 
}
         					  
							  