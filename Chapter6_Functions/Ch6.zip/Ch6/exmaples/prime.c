#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int isPrime(int num){
  int	i;
  if ( num < 3 ) return 1;
  for (i=2; i<=(int) sqrt(num);i++ )
    if ( num % i == 0 ) break;
	if ( num % i ) return 1;
	return 0;
}

int main(void){
  int i;
  for( i = 1; i <= 100; i++ ) {
    printf("%d", i); 
    if ( isPrime(i) ) 

      printf("*");
    if ( i % 10 == 0 )
      printf("\n");
    else
      printf("\t");
  }
  return 0; 
}
