#include <stdio.h>
newI (int I) {
    I = 5;
	printf("In newI: %d\n", I);
}
newI2 (int *I) {*I = 5;
	printf("In newI2: %d\n", *I);
}

int main(void) {
	int 	I;
	I = 4;
	printf("%d\n", I);
	newI(I);
	printf("%d\n", I);
    newI2(&I);
	printf("%d\n", I);
 return 0; 
}