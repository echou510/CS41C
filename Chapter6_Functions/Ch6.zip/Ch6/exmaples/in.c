#include <stdio.h>
static inline int max(a, b) {return  (a>=b) ? a: b;}
			   	   
int main(void){
    int x = 1; 
	int y = 2; 
	
	int c = max(x, y); 
	
    printf("%d %d %d\n", x, y, c); 
}
         					  
							  