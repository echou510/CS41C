#include <stdio.h>
#include <limits.h>
#include <float.h>
#include <math.h>
//#define DEG M_PI/180

double sin(double x){
  double sinValue = 0.0;
  double xSquared;
  double term;
  int n = 1;
  xSquared = x * x;
  term = x;
  while ( fabs(term) > DBL_EPSILON ) {
    sinValue += term;
    n += 2;
    term *= (- xSquared)/(n - 1)/n;
  }
  return sinValue;
}

int main(void){
	int i=0; 
	for (i=0; i<=24; i++) {
		printf("sin(%d)=%10.6f \n", (15*i), sin((double) i*M_PI/12)); 
	}
	return 0; 
}
