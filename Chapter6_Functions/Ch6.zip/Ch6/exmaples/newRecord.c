#include <stdio.h>
#include <stdlib.h>
typedef struct a { int x;  int y;} record; 

record *newRecord(void){
 record *r=calloc(1, sizeof(record)); 
 r->x =0; r->y=0; 
 return r;
}

int main(void){
  record *r = newRecord(); 
  printf("%d %d\n", r->x, r->y); 
  return 0; 
}
