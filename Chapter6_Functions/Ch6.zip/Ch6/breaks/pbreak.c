#include <stdio.h>

int main(){
   int i=0; 
   for (i=0; i<5; i++){
	   if (i==3) { /*pass*/ };
	   printf("%d\n", i); 	   
   }
  printf("End\n"); 
  return 0; 
}

