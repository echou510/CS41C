#include <stdio.h>
#include <stdlib.h>

int main(){
   int i=0; 
   for (i=0; i<5; i++){
	   if (i==3) exit(0);
	   printf("%d\n", i); 	   
   }
  printf("End\n"); 
  return 0; 
}

