#include <stdio.h> 
#include <stdlib.h>
int main(){
    register int number = 1;
    scanf("%d", &number);
    printf("%d", number);
    return 0;
}