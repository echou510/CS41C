public class Random
{
   public static double random(){
       return Math.random(); 
    }
   public static int randInt(int max){
       return (int) (Math.random()*max);
    }
   public static int randomInteger(int baseline, int steps, int count){
       return (int) (Math.random()*count) * steps + baseline; 
    }
}
