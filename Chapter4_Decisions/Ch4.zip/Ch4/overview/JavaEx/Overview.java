public class Overview
{
   final static int SAMPLES=10; 
   
   public static void main(String[] args){
    int i=0; 
    System.out.printf("\f"); 
	for (i=0; i<SAMPLES; i++){
		 System.out.printf("Random Fraction=%6.4f\n", Random.random()); 
	}
	System.out.printf("\n"); 
	for (i=0; i<SAMPLES; i++){
		 System.out.printf("Positive Integer (<10)=%d\n", Random.randInt(10)); 
	}		
	System.out.printf("\n"); 
	for (i=0; i<SAMPLES; i++){
		 System.out.printf("Random(+/- 5) =%d\n", Random.randomInteger(-5, 1, 11)); 
	}		
    }
}
