#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>

void reset_random(void); 
double random(void); 
double randomOne(void); 
uint32_t randInt(uint32_t); 
int randomInteger(int, int, int); 

