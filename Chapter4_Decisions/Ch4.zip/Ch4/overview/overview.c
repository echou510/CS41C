#include <stdio.h>
#include "random.h"
#define SAMPLES 10

extern void reset_random(void); 
extern double random(void); 
extern double randomOne(void); 
extern uint32_t randInt(uint32_t); 
extern int randomInteger(int, int, int); 

int main(int argc, char *argv[]){ // all the same as random.c 
	reset_random();   // reset the random number generator
	
	int i=0; 
	for (i=0; i<SAMPLES; i++){
		 printf("Random Fraction=%6.4f\n", random()); 
	}
	printf("\n"); 
	for (i=0; i<SAMPLES; i++){
		 printf("Positive Integer (<10)=%d\n", randInt(10)); 
	}		
	printf("\n"); 
	for (i=0; i<SAMPLES; i++){
		 printf("Random(+/- 5) =%d\n", randomInteger(-5, 1, 11)); 
	}		
	return EXIT_SUCCESS; 
}