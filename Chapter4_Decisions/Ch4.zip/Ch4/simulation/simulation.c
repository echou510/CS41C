#include <stdio.h>
#include "random.h"
#define SIMULATION 0

extern void reset_random(void); 
extern double random(void); 
extern double randomOne(void); 
extern uint32_t randInt(uint32_t); 
extern int randomInteger(int, int, int); 

char opr;
double num1, num2;

int main(int argc, char *argv[]){
	if (SIMULATION) reset_random();

	// mixed the switch.c with SIMULATION mode
	if (!SIMULATION) {
       printf("Enter an operator (+, -, *, /): ");
       scanf("%c", &opr);
       printf("Enter first operands: ");
       scanf("%lf", &num1); 
	   printf("Enter second operands: ");
	  scanf("%lf", &num2);
	} else {
		int opr1 = randInt(3);
        switch (opr1) {
	       case 0: opr = '+'; break; 
		   case 1:  opr = '-'; break; 
		   case 2: opr = '*'; break; 
		   case 3: opr = '/'; break;  
		}		
		num1 = random() * 100.0; 
		num2 = random() * 100.0; 
	}
	
	// code from switch.c 
    switch(opr){
        case '+':
            printf("%lf + %lf = %lf",num1, num2, num1+num2);
            break;
        case '-':
            printf("%lf - %lf = %lf",num1, num2, num1-num2);
            break;
        case '*':
            printf("%lf * %lf = %lf",num1, num2, num1*num2);
            break;
        case '/':
            printf("%lf / %lf = %lf",num1, num2, num1/num2);
            break;
        // operator is doesn't match any case constant (+, -, *, /)
        default:
            printf("Error! operator is not correct");
    }	
	
	
	return 0; 
}