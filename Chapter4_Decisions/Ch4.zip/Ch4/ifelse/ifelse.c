#include <stdio.h>
 
int main () {
   /* local variable definition */
   int a=0; 
   printf("Enter an integer: "); 
   scanf("%d", &a); 
 
   /* check the boolean condition */
   if( a < 20 ) {
      /* if condition is true then print the following */
      printf("a is less than 20\n" );
   }
   else {
      /* if condition is false then print the following */
      printf("a is not less than 20\n" );
   }
   printf("value of a is : %d\n", a);
   return 0;
}