#include <stdio.h>

int main(int argc, char *argv[]){
   int x = 1; 
   int y =10; 
   int z; 
   if(y<0) if (y>0) x = 3;
   else x=5;
   printf("Output 1: %d\n", x);
   if(z = y < 0) x = 10; 
   printf("Output 2: %d %d\n", x, z); 
   return 0; 
}

