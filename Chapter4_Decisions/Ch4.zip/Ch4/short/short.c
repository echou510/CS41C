#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
  double a; 
  double b; 
  
  printf("Enter Two Numbers: \n");
  scanf(" %lf", &a);
  scanf(" %lf", &b);
 printf("%f %f\n", a, b); 
  if (b !=0.0 &&  a/b >=3) {
	  printf("a/b >= 3 \n"); 
  }  else if (b ==0.0){
	   printf("denominator is 0.0\n");  
  } else{
	  printf("a/b < 3.\n"); 
  }
  return EXIT_SUCCESS; 
}

