#include <stdio.h>
#include <stdlib.h>
int main() {
    char operator;
    double firstNumber, secondNumber;
    printf("Enter an operator (+, -, *, /): ");
    scanf("%c", &operator);
    printf("Enter first operands: ");
    scanf("%lf", &firstNumber); 
	printf("Enter second operands: ");
	scanf("%lf", &secondNumber);

    switch(operator){
        case '+':
            printf("%lf + %lf = %lf",firstNumber, secondNumber, firstNumber+secondNumber);
            break;
        case '-':
            printf("%lf - %lf = %lf",firstNumber, secondNumber, firstNumber-secondNumber);
            break;
        case '*':
            printf("%lf * %lf = %lf",firstNumber, secondNumber, firstNumber*secondNumber);
            break;
        case '/':
            printf("%lf / %lf = %lf",firstNumber, secondNumber, firstNumber/firstNumber);
            break;
        // operator is doesn't match any case constant (+, -, *, /)
        default:
            printf("Error! operator is not correct");
    }
    return 0;
}