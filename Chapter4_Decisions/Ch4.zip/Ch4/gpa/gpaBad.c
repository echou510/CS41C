#include <stdio.h>
#define A 'A'
#define B 'B'
#define C 'C'
#define D 'D'
#define F 'F'
#define N 'N'      // ungraded

int main(int argc, char *argv[]){
    char grade = N;     
    int score =0; 

    printf("Enter your score:"); 
    scanf("%d", &score); 
    if (score < 60){
		grade = F; 
	} else if (score >= 60){
		grade = D; 
	} else  if (score >= 70){
		grade = C; 
	} else  if (score >= 80){
		grade = B; 
	} else {
		grade = A; 
	}; 
	printf("Your grade is %c\n", grade);
    return 0; 	
}