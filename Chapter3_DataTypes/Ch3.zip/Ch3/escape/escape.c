#include <stdio.h>      
#include <conio.h>    
void main(){      
   int number=50;    
   //clrscr();      // clear console screen
   printf("You\nare\nlearning\n\'c\' language\n\"Do you know C language\"\n");  
   
   char ch = getch();      // get a key code     
   printf("ASCII Keycode = %d\n", ch); 
   
}    

