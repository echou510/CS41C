#include "random.h"
//#define DEBUG 1
#define SAMPLES 10

void reset_random(){                   // reset the random number generator with time function
       srand(time(NULL)); 
}

/* random 
*   random number generator generator double number ranging from [0, 1)
*    This function works like Math.random() in Java language
*/
double random(){                      
	 return (double) rand()/ (double) (RAND_MAX+1); 
}

/* randomOne
*   random number generator generator double number ranging from [0, 1]
*    This function works like Math.random() in Java language except 1 is inclusive. 
*/
double randomOne(){                      
	 return (double) rand()/ (double) (RAND_MAX); 
}

/*
*    random unsigned int generator from 0 to max -1 
*/
uint32_t randInt(uint32_t max){
	 return  (uint32_t) (random()*max); 
}

/*
*    Parametric random number generator that start from the "baseline" number, 
*    for every "steps"th number and for total of "count" elements.
*/
int randomInteger(int baseline, int steps, int count){
	 return (int) (random()*count)* steps + baseline; 
}

#ifdef DEBUG
int main(void){
	reset_random();   // reset the random number generator
	
	int i=0; 
	for (i=0; i<SAMPLES; i++){
		 printf("Random Fraction=%6.4f\n", random()); 
	}
	printf("\n"); 
	for (i=0; i<SAMPLES; i++){
		 printf("Positive Integer (<10)=%d\n", randInt(10)); 
	}		
	printf("\n"); 
	for (i=0; i<SAMPLES; i++){
		 printf("Random(+/- 5) =%d\n", randomInteger(-5, 1, 11)); 
	}		
	return EXIT_SUCCESS; 
}
#endif
