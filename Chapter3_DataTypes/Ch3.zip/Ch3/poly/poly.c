#include <stdio.h>
#include <stdlib.h>
#include <sys/file.h>
#include <math.h>

#define LEN 3   // length of the coefficient array
double c[] = {1, -2, 1};  // polynomial 1 - 2 x + x^2 
/**
* x: double varible
* coeff: coefficient array a[0] + a[1]*x^1 + a[2]*x^2 + ... + a[n-1]*x^(n-1)
*/
double poly(double x, double coeff[]){
        double sum=0.0; 
        for (int i=0; i<LEN; i++){
           sum += coeff[i] * pow(x,i); 
        }
        return sum; 
}

/*
* diff: calculation of derivatives
*/
double diff(double yh, double y, int steps){
	  double dt = (double) 1/steps; 
      return (yh - y) * steps;  // take derivatives
}

int main(void){
	FILE *fp = fopen("poly.txt", "w"); 
	fprintf(fp, "Test Derivative of x^2 + 2 x + 1\n");
    double x; 
    for (x = 0.0; x <= 2.01; x+= 0.1){
		  fprintf(fp, "%10.4f \n", x); 
	}	
	fprintf(fp, "\n"); 
	for (x = 0.0; x <= 2.01; x+= 0.1){
		  fprintf(fp, "%10.4f \n", poly(x, c)); 
	}	
	fprintf(fp, "\n"); 
	for (x = 0.0; x <= 2.01; x+= 0.1){
		  double y = poly(x, c); 
		  double yh = poly((x + (1.0/10000.0)), c); 
		  fprintf(fp, "%10.4f \n", diff(yh, y, 10000)); 
	}	
	fprintf(fp, "\n"); 
	fclose(fp); 
	return 0; 
}