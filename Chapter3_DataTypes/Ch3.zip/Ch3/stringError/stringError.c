#include<stdio.h>
main(){
char str1[6] = "Hello"; // “Hello” is a rvalue of pointer type. 
char str2[6]; 
         str2 = "Hello";
char str3[6] = "Hello";   
char str4[6]; 
        str4 = str3; 

// OK region	char str[] works like char *str	in some place but not everywhere.  (when direct declaration with string literals
char str5[] = "Hello"; // “Hello” is a rvalue of pointer type. 
char str6[]; 
         str6 = "Hello";
char str7[] = "Hello";   
char str8[]; 
         str8 = str7; 
		 
// OK region	char str[] works like char *str	  Pointers can take all literals "XXX"
char *str9 = "Hello"; // “Hello” is a rvalue of pointer type. 
char *str10; 
         str10 = "Hello";
char *str11 = "Hello";   
char *str12; 
         str12 = str11; 
		 
// char *str, str[] str[3] can all take declaration and initialization in one statement. 
// char str[] need to be initialized, right away. 
// str[] str[3] cannot take initialization with "literal" directly. 
// char str[] can take array of character directly. 
// but not char *str;  
// char *str; char a[] = {'A', "\0"};      str = a; // using array id as address is OK. 
}