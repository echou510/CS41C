#include <stdio.h>
char mystring[100]; 

main(){
	int i; 
	int done =0; 
    printf("Enter String: ");
    gets(mystring);
    for (i=0; i<100 && !done; i++){
		if (mystring[i] == '\0'){
			done = 1; 
		} 
		else putchar(mystring[i]); 
	}
}

