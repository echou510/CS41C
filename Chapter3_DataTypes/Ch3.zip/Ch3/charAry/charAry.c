#include <stdio.h>
#define LEN 3

main(){
  char a[] = {'a', 'b', 'c'};
  char b[] = {'d', 'e', 'f'};
  char *c   = b; 
  char *d   = (char *) {'k', 'l'}; 
  int i=0; 
  printf("Character Array a[3]="); 
  for (i=0; i<LEN; i++) printf("%c ", a[i]);  printf("\n"); 
  printf("Character Array b[3]="); 
  for (i=0; i<LEN; i++) printf("%c ", c[i]);  printf("\n"); 
}