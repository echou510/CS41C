#include <stdio.h>
char mystring[100]; 

main(){
   int i; 
  printf("Enter String:");
  for (i=0; i<10; i++) mystring[i] = getchar(); 
  mystring[9] = '\0'; 
  printf("\n\n%s", mystring);   
}



