#include <stdio.h>

char mystring[100]; 

main(){
  printf("Enter String:");
  gets(mystring);
  printf("\n\n%s", mystring);   
}