#include <stdio.h>

main(){
   int x = 1, y = 10; int z; 
   if (y<0)
        if (y > 0) x = 3;  // bad indentation
   else x = 5;
   printf("%d\n", x);
   
   if (z = y < 0) x = 10; 
   printf("%d %d\n", x, z);
}