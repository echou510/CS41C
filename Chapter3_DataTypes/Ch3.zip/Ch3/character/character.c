#include <stdio.h> 

main(){
    char a; 
	printf("Uppercase Letters: \n"); 
	for (a=65; a<65+26; a++){
	     printf("ASCII[%d] = %c\n", a, a); 
	}
	
	printf("Lowercase Letters: \n"); 	
	for (a=97; a<97+26; a++){
	     printf("ASCII[%d] = %c\n", a, a); 
	}	
}