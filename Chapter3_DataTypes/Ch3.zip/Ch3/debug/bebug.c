#include <stdio.h>
#define DEBUG 1

main(){
    int i=0; 
    int sum=0; 
    for (i=0; i<10; i++){
	  sum += i; 
	  DEBUG ? printf("Iteration %d: Sum=%d\n", i, sum) : {} ; // Print when in DEBUG mode 
	}	
	printf("Sum[0..9]=%d\n", sum); 
}