#include <stdio.h>
#undef DEBUG
//#define DEBUG 0

main(){
    int i=0; 
    int sum=0; 
    for (i=0; i<10; i++){
	  sum += i; 
	  #ifdef DEBUG
	  printf("Iteration %d: Sum=%d\n", i, sum); // Print when in DEBUG mode 
	  #endif
	}	
	printf("Sum[0..9]=%d\n", sum); 
}