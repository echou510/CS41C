#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

char *check(bool b){
	char *a=malloc(sizeof(char)); 
	a = b ? "true" : "false"; 
	return a; 
}
int main(){
	printf("%s\n", ""); 
	printf("%c","hello"[1]);
	char string1[6] = "hello";
	char string2[6] = "hello";
	bool string_equal_sign = string1 == string2; 
	bool string_equal_equal = strcmp(string1, string2) ? false : true; 
    char *s1 = check(string_equal_sign);
    char *s2 = check(string_equal_equal);  	
	printf("Operator == check = %s\n", s1); 
	printf("Operator strcmp     = %s\n", s2); 
	return 0; 
}



