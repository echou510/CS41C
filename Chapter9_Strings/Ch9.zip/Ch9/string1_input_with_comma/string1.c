#include <stdio.h>
void main() {
  char LastName[11];
  char FirstName[11];
  printf("Enter your name (last , first): ");
  scanf("%10s%*[^,],%10s", LastName, FirstName);
  printf("Nice to meet you %s %s\n", FirstName,LastName);
}
