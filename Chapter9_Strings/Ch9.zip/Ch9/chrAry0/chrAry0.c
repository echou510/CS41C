#include <stdio.h>
#include <stdlib.h>

char   a1[] = "Undefined Array. ";
char   a2[256] = "Array of Fixed Size. "; 
//char *a3 = "Pointer of character Doest not work. "  
char  a4[] = {'A','r','r', 'a', 'y', 'o', 'f', ' ', 'C', 'h', 'a', 'r', 'a','c','t','e','r','s', '\0'}; 
char *a5;  
int main(){
	a5 = (char *)calloc(256, sizeof(char)); 
	a5 = "array in heap"; 
	printf("%s\n", a1); 
	printf("%s\n", a2); 
	//printf("%s\n", a3); 
	printf("%s\n", a4); 
	printf("%s\n", a5); 
	return 0; 
}

