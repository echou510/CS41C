#include <stdio.h>
#include <stdlib.h>

char Name[11]; 
char Number[13];
char Address[256]; 

int main(){
	printf("Enter your first name: ");   // unguarded input
	scanf("%s", Name);                              
	printf("Enter your name again: ");
    scanf("%10s", Name); 	
	getchar();                                // consume the extra \n char input.nextLine()
	printf("Enter your phone number: ");
	scanf("%[-+0123456789]", Number);  // equal to next() for phone numbers and dash in C 
	getchar();                                // consume the extra \n char input.nextLine()        
	printf("Enter your address: ");
    scanf("%[^\n]", Address);
    getchar();                                // consume the extra \n char input.nextLine()
	printf("\n%s\n", Name); 
	printf("%s\n", Number);
    printf("%s\n", Address); 	
	printf("\n\n\nExtra Demos"); 
	char Name1[11] = "Rich";
	printf("|%s|\n",Name1); /* outputs |Rich| */
	printf("|%10s|\n",Name1); /* outputs |      Rich| */
	printf("|%-10s|\n",Name1); /* outputs |Rich      | */
	return 0; 
}


