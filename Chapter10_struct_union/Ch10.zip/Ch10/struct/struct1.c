#include <stdio.h>
struct Person{
    char name[50];
    int citNo;
    float salary;
};

int main(){
    struct Person person1, person2, p[20];
    return 0;
}