#include <stdio.h>
#include <stdlib.h>

int main(void){
  char *filename = "declare.txt"; 
  FILE *fp = fopen(filename, "r");
  int ch = getc(fp);
  int count=0; 

  while (ch != EOF) {
    /* display contents of file on screen */
    putchar(ch); 
    if ((ch<=90 && ch>=65) || (ch<=122 && ch>=97))  count++; 
    ch = getc(fp);
  }
  printf("File %s has %d letters.\n", filename, count); 
  if (feof(fp))
     printf("\n End of file reached.");
  else
     printf("\n Something went wrong.");
  fclose(fp);
  printf("\n\n<<Hit a Key to end>>\n"); 
  getchar();
  return 0;
}

