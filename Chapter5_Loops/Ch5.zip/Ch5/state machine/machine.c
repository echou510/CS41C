#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

typedef enum{
    STATE_1 = 1,
    STATE_2 =2,
    STATE_3 =3
} my_state_t;

my_state_t state = STATE_1;

void stateMachine(uint8_t input){
    switch(state){   // nested case-switch statements
        case STATE_1:
		   printf("State %d:\n", state); 
		   switch (input){
			   case 'A':
			   printf("Input %c ---> State %d\n", input, state); 
			   break; 
			   case 'B':
			   state = STATE_2; 
			   printf("Input %c ---> State %d\n", input, state);   
			   break; 
			   case 'C':
			   state = STATE_3; 
			   printf("Input %c ---> State %d END\n", input, state);    
			   break; 			   
		   }
         break;
        case STATE_2:		   
		   printf("State %d:\n", state); 
		   switch (input){
			   case 'A': 
			   state = STATE_1; 
			   printf("Input %c ---> State %d\n", input, state);    
			   break; 
			   case 'B':
			   printf("Input %c ---> State %d\n", input, state);      
			   break; 
			   case 'C':
			   state = STATE_3; 
			   printf("Input %c ---> State %d END\n", input, state);     
			   break; 			   
		   }		
         break;
        case STATE_3:
		   printf("State %d:\n", state); 
		   switch (input){
			   case 'A':
			   case 'B':
			   case 'C':
			     printf("Input %c ---> State No Change\n", input);
			   break; 			   
		   }
		break;
    }
}

int main(void){
  char *filename = "state.txt"; 
  FILE *fp = fopen(filename, "r");
  int ch = getc(fp);
  //int count=0; 

  while (ch != EOF) {
    /* display contents of file on screen */
    if (ch <='C' && ch>='A') stateMachine((uint8_t) ch); 
    ch = getc(fp);
  }
  
  if (feof(fp))
     printf("\n End of file reached.");
  else
     printf("\n Something went wrong.");
  fclose(fp);
  return 0;
}
