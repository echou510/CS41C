#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
//# define DEBUG
 /*
 funcion not in standard C library
 */
 char *strlwr(char *str){
  unsigned char *p = (unsigned char *)str;
  while (*p) {
     *p = tolower((unsigned char)*p);
      p++;
  }
  return str;
}

char *trim(char *str) { // trimming any non-letter characters. 
    char ptr[strlen(str)+1];
    int i,j=0;
    for(i=0;str[i]!='\0';i++) {
        if ((str[i]>=65 && str[i]<=90) || (str[i]>=97 && str[i]<=122))   ptr[j++]=str[i];
    } 
    ptr[j]='\0';
    strcpy(str, ptr);
} 

//char *tokenv[]; 
int main(void){
  char *filename = "declare.txt"; 
  FILE *fp = fopen(filename, "r");
  char *token = (char *) calloc(512, sizeof(uint8_t)); 
  int count=0; 
 
  while (!feof(fp)) {  // token count
	 fscanf(fp, " %s", token); 
     count++; 	 
  } // token count
  printf("Token Count:%d\n", count); 
  rewind(fp); 
  char *tokens[count]; 
  int i=0;
  int top=0;   
  while (!feof(fp)) {  // outer loop token processing
     fscanf(fp, " %s", token); 	 
	 trim(token);
	 strlwr(token); 	 
	 
	if (strcmp(token, "\0") != 0 ){  // inner loop for checking if existing
	    int found =0; 
	    i=0; 
	    for (i=0; i<top && !found; i++){ 
   	        if (strcmp(token, tokens[i])==0) found = 1; 
	     }
	    if (!found){
		     tokens[top] = calloc(128, sizeof(uint8_t));
			 strcpy(tokens[top++], token); 
	     } 
	 }// inner loop for checking existing tokens
  } // outer loop token processing
  printf("# of Identical Words=%d\n", top); 
  #ifdef DEBUG
  for (i=0; i<top; i++) printf("%s\n", tokens[i]); 
  #endif 
  return 0;
}

