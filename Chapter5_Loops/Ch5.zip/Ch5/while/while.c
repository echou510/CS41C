#include <stdio.h>

int main(int argc, char *argv[]){
	int i=0, x=0 ;
    while (i<10) { 
        if(i%3==0) {
             x += i;
             printf("%d ", x);
          }
          ++i;
     }
	 return 0; 
}