#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

int main(void){
	int choice=0;	
	int done = 0; 
	char *data = calloc(256, sizeof(uint8_t)); 
    do {
		printf("What drink do you like?\n");
        printf("   1. Coke\n"); 		 
		printf("   2. Sprite\n"); 		 
		printf("   3. Dr. Pepper\n"); 		 
		printf("   4. Root Beer\n"); 		 
		printf("   5. Mountain Dews\n"); 		
		printf("   Exit to quit this system: ");
		scanf("%s", data); 
		if (strcmp(data, "Exit") != 0 && strcmp(data, "exit") != 0 && strcmp(data, "EXIT") != 0){
		   	 choice = atoi(data); 
			 if (choice >0 && choice <=5) {
				 printf("Choice %d is made.\n", choice); 
				 done =1; 
			 }
		}
		if (strcmp(data, "Exit") == 0 || strcmp(data, "exit") == 0 || strcmp(data, "EXIT") == 0){
		   	 done =1; 
		}
	}	while (!done); 
	// do something with the choice here. 
}