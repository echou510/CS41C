#include<stdio.h>
#include<conio.h>

void main(){
   int j,i;
   printf("Multiplication table from 1 to 19 \n\n");
  for(i=1; i<=19; i++){  
      for(j=1; j<=19; j++) printf("%5d",i*j);
      printf("\n");
   }
}

