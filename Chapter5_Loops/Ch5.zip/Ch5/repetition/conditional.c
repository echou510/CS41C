#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
     int continued = 1; 
	 char input; 
	 while (continued) {
		 printf("Welcome to C!\n"); 
		 printf("Do you want to continue (Y/N)?");
         input = getch(); 		 
		 printf("%c\n", input); 
		 if (input == 'N' || input == 'n') continued = 0; 
	 }
	 return 0; 
}