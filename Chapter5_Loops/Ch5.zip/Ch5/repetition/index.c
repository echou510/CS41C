#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	 char input; 
	 int i; 
	 for (i=0; i<10; i++){
		 printf("Welcome to %d!\n", i); 
	 }
	 return 0; 
}