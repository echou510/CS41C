#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	 char input; 
	 int done = 0; 
	 int i; 
	 for (i=0; i<10 && !done; i++){
		 printf("Welcome to %d!\n", i); 
		 printf("Done? (Y/N)");
         input = getch(); 
         printf("%c\n", input);
         if (input == 'Y' || input == 'y') done = 1;   		 
	 }
	 return 0; 
}