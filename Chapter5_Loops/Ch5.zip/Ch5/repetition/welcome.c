#include <stdio.h>

int main(int argc, char *argv[]){
     int i=0; 
	 while (i<10) {
		 printf("Welcome to C!\n"); 
		 i++; 
	 }
	 return 0; 
}