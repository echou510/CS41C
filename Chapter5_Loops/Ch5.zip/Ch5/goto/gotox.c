#include <stdio.h>

int main(void){
   int i=0; 
   whilex: 
   if (i<10){
	  printf("Index %d\n", i); 
      i++; 
	  goto whilex; 
   }

   return 0; 
}

