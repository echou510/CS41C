#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int a[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, INT_MIN}; 
int main(int argc, char *argv[]){
     int i =0; 
	 int sum = 0; 
	 while (a[i] != INT_MIN){
		  sum += a[i]; 
		  i++; 
	 }
	 printf("Sum=%d\n", sum); 
	 return 0; 
}

