#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdint.h>
#include "random.h"

extern uint32_t randInt(uint32_t); 

int main(void){
	 int sum = 0;   
	 reset_random(); 
    
	 for (int i=0; i<10; i++){
		 uint32_t x = randInt(10);
		 sum+= x; 
		 printf("%d is added\n", x); 
	 }
	 printf("Sum=%d\n", sum); 
	 return 0; 
}

