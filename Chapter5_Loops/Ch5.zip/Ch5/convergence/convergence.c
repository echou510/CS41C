#include <stdio.h> 
#include <math.h>
#include <float.h>
#define MIN_STEP 0.00001

double f(double x){ // f(x)
	return x*x; 	
}

double fp(double x){  // first order derivative of f(x) -> f'(x)
	return 2*x;  
}

int main(void){
    double x0=0; 
	double x1=1;
	printf("%f\n", x1); 
	do {
		x0=x1;
	    x1=x0-f(x0)/fp(x0); 
		printf("%f\n", x1); 
     } while ( fabs(x1-x0)>MIN_STEP) ;
	 
	 //
	printf("\n\n\n"); 
	x0=0; 
	x1=1;
	printf("%f\n", f(x1)); 
	do {
		x0=x1;
	    x1=x0-f(x0)/fp(x0); 
		printf("%f\n", f(x1)); 
     } while ( fabs(x1-x0)>MIN_STEP) ;
    return 0; 
}