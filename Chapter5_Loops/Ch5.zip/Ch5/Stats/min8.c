#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define LEN 13
int a[] = {9, 14, 5, 10, 1, 3, 4, 7, 1, 6, 8, 14, 3};

int main(void){
	int min = a[0]; 
	int i; 
	int minIndex=0; 
	for (i=1; i<LEN; i++){
		 if (a[i]<=min) {
			 min = a[i]; 
			 minIndex = i; 
		 }
	}
	printf("Min Index=%d    Minimum=%d\n", minIndex, min); 
	return 0; 
}  
