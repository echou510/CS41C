#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(int argc, char *argv[]){
	 int sum = 0;
	 int intss = 0; 
	 int i=0.0; 
	 double avg=0.0; 
     char data[256]; 	       
	 int done; 	
    do{	
       done = 1; 
	   printf("Enter an integer (or Exit to quit): ");  
	   scanf("%s", data);	 
	   if (strcmp(data, "Exit") != 0 && strcmp(data, "exit") != 0 && strcmp(data, "EXIT") != 0){
		  intss = atoi(data); 
		  sum += intss; 
		  done = 0; 
		  i++; 
	   }
	 } while (!done); 
	 printf("Sum=%d\n", sum); 
	 avg = (double) sum/i; 
	 printf("Avg=%f\n", avg); 
	 return 0; 
}


