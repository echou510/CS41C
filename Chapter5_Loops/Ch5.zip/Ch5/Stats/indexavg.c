#include <stdio.h>
#include <stdlib.h>
#define LEN 10

int a[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }; 
int main(int argc, char *argv[]){
     int i =0; 
	 int sum = 0; 
	 double avg =0.0; 
	 for (i=0; i<LEN; i++){
		  sum += a[i]; 
	 }
	 printf("Sum=%d\n", sum); 
	 avg = (double) sum/i; 
	 printf("Avg=%f\n", avg); 
	 return 0; 
}