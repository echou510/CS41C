#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define LEN 13
int a[] = {9, 14, 5, 10, 1, 3, 4, 7, 1, 6, 8, 14, 3};

int main(void){
	int max = INT_MIN; 
	int i=0; 
	int maxIndex=0; 
	for (i=0; i<LEN; i++){
		 if (a[i]>max) {
			 max = a[i]; 
			 maxIndex = i; 
		 }
	}
	printf("MaxIndex=%d    Maximum=%d\n", maxIndex, max); 
	return 0; 
}  