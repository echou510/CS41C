#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void){
    int i;
	int count; 
	int n=4;  printf("  2   3 "); 
    for (count = 2; count< 50; n++){
	  for ( i = 2; i <= (int) sqrt(n); i++ ) {
            if ( n % i == 0 ) break;   // break when it is not a prime number
       }
	  if (n%i !=0) { 
	      printf("%3d ", n);
		  if (count % 10 == 9) printf("\n");
          count++; 		  
	  }
	  //n++; 
     }
}

