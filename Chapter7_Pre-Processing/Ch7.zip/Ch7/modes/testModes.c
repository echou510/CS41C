#include <stdio.h> 

int main(void){
  printf("Compilation Test Modes:\n"); 
  return 0; 
}

