#include <stdio.h>
int x; 
int f(){
  x=0; 
  x++; 
  printf("In a.c f() \n"); 
  return x; 
}

