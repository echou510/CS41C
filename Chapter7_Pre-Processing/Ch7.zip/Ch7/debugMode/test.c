#include <stdio.h>
#include <a.h>
extern int x; 
int main(void){
   f(); 
   x++; 
   printf("x=%d in f()\n", x);
   return 0;    
}

