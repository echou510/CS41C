#ifndef INX
#define INX
extern int f(); 
#endif 