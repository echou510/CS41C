#include <stdio.h>
//#define DEBUG
#undef DEBUG
int x; 
int f(){
  x=0; 
  x++; 
  printf("In a.c f() \n"); 
  return x; 
}

#if defined(DEBUG)
int main(void){
   f(); 
   x++; 
   printf("x=%d in f()\n", x);
   return 0;    
}
#else 
int main(void){
   printf("Undefiend DEBUG\n");
   return 0;    
}
#endif


