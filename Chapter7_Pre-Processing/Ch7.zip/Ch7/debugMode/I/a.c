#include <stdio.h>
//#define DEBUG
int x; 
int f(){
  x=0; 
  x++; 
  printf("In a.c f() \n"); 
  return x; 
}

#ifdef DEBUG
int main(void){
   f(); 
   x++; 
   printf("x=%d in f()\n", x);
   return 0;    
}
#endif



