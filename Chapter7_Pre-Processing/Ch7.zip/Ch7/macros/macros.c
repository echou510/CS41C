#include <stdio.h>
#define ALEN 10

int a[ALEN]; 
#define SQ(x)  (x = (x) * (x))

int main(void){
    for (int i=0; i<ALEN; i++){  // macro object expansion
	     a[i] = i; 
		 SQ(a[i]);  // macro function expansion 
		 printf("a[%d]=%d\n", i, a[i]); 
	}
}


