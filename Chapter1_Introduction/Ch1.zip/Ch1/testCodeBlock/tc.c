#include <stdio.h>

int main(){
  for (int i=0; i<3; i++){
    printf("I am fine");
  }
  return 0;
}
