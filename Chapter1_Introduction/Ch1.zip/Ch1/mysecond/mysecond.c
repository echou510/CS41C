#include <stdio.h>
int main() {
   /* this program adds
   two numbers */
   int a = 4; //first number
   int b = 5; //second number
   int res = 0; //result
   res = a + b;
   printf("%d + %d = %d\n", a, b, res); 
   return 0; 
}
