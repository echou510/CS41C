/* thou shalt begin from somewhere*/
#include <stdio.h>
// program prints hello world
int main() {
	printf ("Hello world!\n");
	return 0;
}
