#include <stdio.h> 

int min(int a, int b){
   return (a<= b ? a : b) ; 
}
int main(void){
 int x, y; 
  x = 1; 
  y = min(x++, x++); 
  
  printf("x=%d, y=%d\n", x, y); 
  return 0; 
}

