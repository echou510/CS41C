#include <stdio.h> 

struct a{
  int x; 
  int y; 
} s; 


struct b {
	int x ; 
	int y; 
}; 

int main(void){
  struct b t; 
  
   s.x=3; 
   s.y = 5; 
   printf("%d %d\n", s.x, s.y); 
   t.x=4; 
   t.y = 5; 
   printf("%d %d\n", t.x, t.y); 
   return 0; 
}