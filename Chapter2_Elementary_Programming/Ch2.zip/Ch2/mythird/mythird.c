#include <stdio.h>
int x; 
int main(void){
	x =3; 
	printf("X=%d\n", x);
	return 0; 
}

