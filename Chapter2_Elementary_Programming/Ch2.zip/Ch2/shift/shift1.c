#include <stdio.h>

int main(void){
   unsigned int a = 64; 
   printf("Shift Operators:\n"); 
   printf("%d shifted right %d bit = %d\n", a, 1, a>>1);    
   printf("%d shifted right %d bit = %d\n", a, 2, a>>2);    
   printf("%d shifted right %d bit = %d\n", a, 3, a>>3); 
   return 0;
}