//Example for increment operators
 
#include <stdio.h>
int main()
{
     int i=1;
     while(i<10)
     {
         printf("%d ",i);
         i++;
     }    
	 return 0; 
}