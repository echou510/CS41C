//Example for decrement operators
 
#include <stdio.h>
int main()
{
    int i=20;
    while(i>10)
    {
         printf("%d ",i);
         i--;
    }    
}