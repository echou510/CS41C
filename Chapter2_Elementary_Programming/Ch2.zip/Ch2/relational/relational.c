#include <stdio.h>
 
int main(){
   int m=40, n=20;
   if (m == n){
       printf("m and n are equal");
   }
   else{
       printf("m and n are not equal");
   }
}