/* Compute Area and Perimeter of  a circle */
#include <stdio.h>
float pi = 3.14159;  /* Global */

int main(void) {
  float rad; /* Local */
  float area; 
  float peri; 
  
  printf( "Enter the radius: ");
  scanf("%f" , &rad);

  if ( rad > 0.0 ) {
    float area = pi * rad * rad;
    float peri = 2 * pi * rad;

    printf("Area = %f\n" , area);
    printf("Perimeter = %f\n" , peri );
  }
  else
    printf("Negative radius\n");

  return 0; 
}
