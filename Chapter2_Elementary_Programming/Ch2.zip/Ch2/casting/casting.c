#include <stdio.h>

int main(void){
      unsigned char a = 65; 
	  
	  printf("Character and Char-size Integer\n"); 
	  printf("Character %c, ASCII code=%d\n", (char) a, a); a++;  
	  printf("Character %c, ASCII code=%d\n", (char) a, a); a++; 
	  printf("Character %c, ASCII code=%d\n", (char) a, a); a++; 
	  
	  int b = a;  // implicit casting
	  printf("Original %d to Destination %d \n", a, b); 
	  printf("To Character %c\n", (char) b); 
}