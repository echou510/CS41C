#include <stdio.h>
int main(){
	 int num1; 
	 num1 = 5; 
	 
	 float num2; 
	 num2 = 2.5; 
	 
	 double num3; 
	 num3 = 125.24683579; 
	 
	 char letter; 
	 letter = 'a'; 
	 
	 printf("Integer=%d, Float=%f, Double=%10.4f, Character=%c\n", num1, num2, num3, letter); 	 
	 return 0; 
}